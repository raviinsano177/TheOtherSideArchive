# The Other Side Archive

Este repositório contém o site misterioso usado em um RPG de terror psicológico.

## Como hospedar no GitHub Pages

1. Faça login no [GitHub](https://github.com) e crie um repositório público (por exemplo, `TheOtherSideArchive`).
2. Envie o arquivo `index.html` (e este README) para o repositório.
3. Vá em **Settings → Pages** e configure:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ (root)`
4. Após alguns segundos, o site estará disponível em:
   ```
   https://seuusuario.github.io/TheOtherSideArchive/
   ```

O enigma principal está oculto dentro do código-fonte (HTML comment).
